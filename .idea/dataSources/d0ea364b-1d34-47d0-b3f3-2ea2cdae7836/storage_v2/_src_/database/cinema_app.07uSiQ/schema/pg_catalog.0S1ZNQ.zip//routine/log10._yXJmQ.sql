create function log10(numeric) returns numeric
    immutable
    strict
    parallel safe
    cost 1
    language sql
RETURN log((10)::numeric, $1);

comment on function log10(numeric) is 'base 10 logarithm';

alter function log10(numeric) owner to postgres;

